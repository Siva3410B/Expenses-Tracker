const display = document.getElementById("display");

function appendToDisplay(input){
    display.value += input;
}

function clearDisplay(){
    display.value = "";
}

function calculate(){
    try{
        display.value = eval(display.value);
    }
    catch(error){
        display.value = "err";
    }
    
}


function backFunction(){
    let value1 = display.value;

    if(value1.length > 0){
        value1 = value1.slice(0, -1); // Remove the last character
        display.value = value1; // Update the input field value
    }
}
