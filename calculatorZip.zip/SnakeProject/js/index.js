
//Game Constants and Variables
let inputDirection = { x: 0, y: 0 }

const foodSound = new Audio('food.mp3');
const gameOverSound = new Audio('gameover.mp3');
const moveSound = new Audio('move.mp3');
const backgroundMusicSound = new Audio('music.mp3');
let speed = 15;
let lastPaintTime = 0;      
//for Position
let snakeArray = [
    { x: 13, y: 15 }
]
//Food Object
food = { x: 6, y: 7 };
let score = 0;



//Game Function

function main(ctime) {

    window.requestAnimationFrame(main);
    // console.log(ctime);
    if ((ctime - lastPaintTime) / 1000 < 1 / speed) {
        return;
    }
    lastPaintTime = ctime;
    gameEngine();
}


function isCollide(snake){
   
   
    //if snake eat itself 
    for (let i = 1; i < snakeArray.length; i++){
        if(snake[i].x === snake[0].x && snake[i].y === snake[0].y){
            return true;
        }
    }

    // if snake hits wall
        if(snake[0].x >= 18 || snake[0].x <= 0 || snake[0].y >= 18 || snake[0].y <= 0){
            return true;
        }
    
}



function gameEngine() {
    //2.Update the Snake Array & Food
    if (isCollide(snakeArray)) {
        gameOverSound.play();
        backgroundMusicSound.pause();
        inputDirection = { x: 0, y: 0 };
        alert("Game Over, Press Any Key To Play Again..!");
        snakeArray = [{ x: 13, y: 15 }]
        backgroundMusicSound.play()
        score = 0;
    }


    // if you have eaten the food, increment the score and regenerate the food.
    if(snakeArray[0].y === food.y && snakeArray[0].x === food.x){
        foodSound.play();
        score += 1;

        // if(score > highscoreval){
        //     highscoreval = score;
        //     localStorage.setItem("highscore",JSON.stringify(highscoreval));
        //     highScoreBox.innerHTML = "HighScore : "+highscore;
        // }
        scoreBox.innerHTML = "Score : "+score;
        snakeArray.unshift({x: snakeArray[0].x + inputDirection.x , y: snakeArray[0].y + inputDirection.y})
        let a = 2;
        let b = 16;
        food = {x: Math.round(a+ (b-a)*Math.random()) , y: Math.round(a+ (b-a)*Math.random())}
    }

    // Moving the snake 
    for(let i = snakeArray.length-2 ; i >= 0 ; i--){
         snakeArray[i+1] = {...snakeArray[i]};
    }

    snakeArray[0].x += inputDirection.x;
    snakeArray[0].y += inputDirection.y;


    //1.Display/Render the Snake & Food

    //-->Display Snake

    //Before start board is to be empty
    board.innerHTML = "";
    //Loop for game
    snakeArray.forEach((element, index) => {

        //create snake element on board
        snakeElement = document.createElement('div');
        snakeElement.style.gridRowStart = element.y;
        snakeElement.style.gridColumnStart = element.x;
        if (index === 0) {
            snakeElement.classList.add('head');
        }
        else {
            snakeElement.classList.add('snake');
        }

        board.appendChild(snakeElement);
    })

    //-->Food Element
    foodElement = document.createElement('div');
    foodElement.style.gridRowStart = food.y;
    foodElement.style.gridColumnStart = food.x;
    foodElement.classList.add('food');
    board.appendChild(foodElement);
}






//main logic started here
// let highscore = localStorage.getItem("highscore");

// if(highscore === null){
//     highscoreval = 0;
//     localStorage.setItem("highscore",JSON.stringify(highscoreval));
// }
//  else{
//     highscoreval = JSON.parse(localStorage.getItem("highscore1"))
//     highScoreBox.innerHTML = "HighScore : "+highscoreval;
//  }

window.requestAnimationFrame(main);
window.addEventListener('keydown', e => {
    inputDirection = { x: 0, y: 1 }  //start the  game
    moveSound.play();

    switch (e.key) {
        case "ArrowUp":
            console.log("Arrow Up");
            inputDirection.x = 0;
            inputDirection.y = -1;
            break;

        case "ArrowDown":
            console.log("Arrow Down");
            inputDirection.x = 0;
            inputDirection.y = 1;
            break;

        case "ArrowLeft":
            console.log("Arrow Left");
            inputDirection.x = -1;
            inputDirection.y = 0;
            break;

        case "ArrowRight":
            console.log("Arrow Right");
            inputDirection.x = 1;
            inputDirection.y = 0;
            break;

        default:
            break;
    }
});


